/**
 * @swagger
 * /starbucks:
 *   get:
 *      summary: 커피메뉴 리스트 가져오기.
 *      responses:
 *          200:
 *              description: 커피메뉴 리스트를 가져옵니다.
 */
